#!/usr/bin/env python
# coding: utf-8

"""
See :mod:`can.logger`.
"""

from __future__ import absolute_import

from can.logger import main


if __name__ == "__main__":
    main()
