isCAN
=====

Interface for isCAN from `Thorsis Technologies GmbH`_, former ifak system GmbH.


Bus
---

.. autoclass:: can.interfaces.iscan.IscanBus

.. autoexception:: can.interfaces.iscan.IscanError


.. _Thorsis Technologies GmbH: https://www.thorsis.com/en/industrial-automation/usb-interfaces/can/iscan-usb-interface/
