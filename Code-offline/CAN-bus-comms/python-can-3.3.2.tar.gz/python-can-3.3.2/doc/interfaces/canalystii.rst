CANalyst-II
===========

CANalyst-II(+) is a USB to CAN Analyzer. The controlcan library is originally developed by
`ZLG ZHIYUAN Electronics`_.


Bus
---

.. autoclass:: can.interfaces.canalystii.CANalystIIBus


.. _ZLG ZHIYUAN Electronics: http://www.zlg.com/can/can/product/id/42.html
