from . import FormulaClient, messages
from .FormulaClient import ClientSource, DW_TIMEOUT_INFINITE
import threading

class ModuleClient(threading.Thread):
    def __init__(self, source, read_from_file, write_to_file, *, default_timeout=5, default_timeout_message_read=1000000, daemon=True):
        super().__init__(daemon=daemon)
        self._source = source
        self._client = FormulaClient.FormulaClient(source, read_from_file, write_to_file) 
        self._running = False   
        self._conn = None
        self._timeout = default_timeout
        self._inner_timeout = default_timeout_message_read

    def connect(self, timeout_us):                                                                         
        self._conn = self._client.connect(port=FormulaClient.SYSTEM_RUNNER_IPC_PORT, timeout=timeout_us)           
        
    def set_read_delay(self, delay):
        self._conn.read_delay = 0.05

    def _callback(self, msg):
        pass

    def send_message(self, msg, timeout=DW_TIMEOUT_INFINITE):
        msg.header.source = self._source.value
        msg.header.timestamp.CopyFrom(messages.get_proto_system_timestamp())
        msg.header.steady_timestamp.CopyFrom(messages.get_proto_steady_timestamp())
        self._conn.send_message(msg, timeout)

    def stop(self):
        self._running = False

    def exception_callback(self, e):
        pass

    def run(self):
        self._running = True
        while(self._running):
            try:
                new_msg = self._conn.read_message(self._timeout, self._inner_timeout)
                if new_msg is not None:
                    self._callback(new_msg)
            except Exception as e:
                self.exception_callback(e)
