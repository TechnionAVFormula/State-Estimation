import os
import pymongo
import zstandard

import argparse


def get_camera_pixels(msg, pixels_path):
    camera_type = msg['data']['@type'].replace('type.googleapis.com/', '')
    msg_id = msg['header']['id']
    file_name = f'{camera_type}_{msg_id}.pixels.zst'
    cctx = zstandard.ZstdDecompressor()
    with open(os.path.join(pixels_path, file_name), 'rb') as pixels_file:
        pixels = cctx.decompress(pixels_file.read())
    return pixels


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('db', help='db name')
    parser.add_argument('camera_type', choices=['depth', 'rgb'], help='Camera type')
    parser.add_argument('pixels_dir', help='Dir for pixels files')
    args = parser.parse_args()

    client = pymongo.MongoClient()
    col_name = None
    if args.camera_type == 'depth':
        col_name = 'TechnionFormulaAV.Messages.DepthCameraSensor'
    elif args.camera_type == 'rgb':
        col_name = 'TechnionFormulaAV.Messages.CameraSensor'

    db = client[args.db]
    col = db[col_name]
    for msg in col.find():
        print(msg)
        pixels_size = msg['data']['width'] * msg['data']['height'] * 4 
        pixels = get_camera_pixels(msg, args.pixels_dir)
        print(f'{len(pixels)} == {pixels_size}')
        print()


if __name__ == '__main__':
    main()
