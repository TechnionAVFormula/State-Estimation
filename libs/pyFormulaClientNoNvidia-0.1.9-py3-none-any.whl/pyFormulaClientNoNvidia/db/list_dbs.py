import pymongo

def list_dbs(client):
    dbs = client.list_database_names()
    return list(filter(lambda x: x.startswith('formula'), dbs))

def main():
    print(list_dbs(pymongo.MongoClient()))

if __name__ == '__main__':
    main()
