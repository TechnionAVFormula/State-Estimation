from ._proto import common_pb2 as common
from ._proto import server_pb2 as server
from ._proto import sensors_pb2 as sensors
from ._proto import perception_pb2 as perception
from ._proto import state_est_pb2 as state_est
from ._proto import control_pb2 as control
from ._proto import ground_truth_pb2 as ground_truth

from google.protobuf import timestamp_pb2

def get_proto_steady_timestamp():
    msg_timestamp = timestamp_pb2.Timestamp()
    msg_timestamp.GetCurrentTime()
    return msg_timestamp

def get_proto_system_timestamp():
    msg_timestamp = timestamp_pb2.Timestamp()
    msg_timestamp.GetCurrentTime()
    return msg_timestamp
