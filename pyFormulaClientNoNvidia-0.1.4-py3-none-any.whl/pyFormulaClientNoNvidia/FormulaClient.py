from enum import IntEnum, unique
import threading
import struct
import time

from . import messages as _messages

SYSTEM_RUNNER_IPC_PORT = 0
DW_TIMEOUT_INFINITE=0

@unique
class ClientSource(IntEnum):
    CONTROL = _messages.common.CONTROL_MODULE
    STATE_EST = _messages.common.STATE_EST_MODULE
    PERCEPTION = _messages.common.PERCEPTION_MODULE
    SERVER = _messages.common.SERVER 

class FormulaClient:
    def __init__(self, source, read_from_file=None, write_to_file=None):
        self._write_to_file = write_to_file
        self._read_from_file = read_from_file
        self._source = source

    def connect(self, port, timeout=DW_TIMEOUT_INFINITE):
            return FormulaClientConnection(self._source, self._read_from_file, self._write_to_file)

class FormulaClientConnection:
    def __init__(self, source, read_from_file, write_to_file):
        self._source = source
        self._read_file = open(read_from_file, 'rb')
        self._write_file = open(write_to_file, 'wb')
        self.read_delay = 0

    def read_message(self, timeout=DW_TIMEOUT_INFINITE):
        time.sleep(self.read_delay)
        size_buffer = self._read_file.read(4)
        if len(size_buffer) == 0:
            msg = _messages.common.Message()
            data = _messages.server.ExitMessage()
            msg.data.Pack(data)
            return msg
        msg_size = struct.unpack("I", size_buffer)[0]
        msg_buffer = self._read_file.read(msg_size)
        msg = _messages.common.Message()
        msg.ParseFromString(msg_buffer)
        return msg

    # Need to check if should use 2 connections (one for reading one for writing) to be thread-safe
    def send_message(self, message, timeout=DW_TIMEOUT_INFINITE):
        buffer = message.SerializeToString()
        size_buffer = struct.pack("I", len(buffer))
        self._write_file.write(size_buffer)
        self._write_file.write(buffer)
        self._write_file.flush()
